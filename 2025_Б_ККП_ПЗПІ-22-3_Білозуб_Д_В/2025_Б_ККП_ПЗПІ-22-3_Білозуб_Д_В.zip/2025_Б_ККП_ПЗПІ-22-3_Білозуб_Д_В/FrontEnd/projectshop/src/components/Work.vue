<template>
  <div class="shop-prof">
    <div class="container">
      <button class="btn back-btn" @click="goBack">Back to shop</button>
      <div class="shop-one">
        <h1 class="shop-name">Shop: {{ shop.name }}</h1>
        <div class="shop-head">
          <h2 class="shop-address">Address: {{ shop.location }}</h2>
          <h3 class="work-schedule">Work schedule: {{ shop.work_schedule }}</h3>
        </div>
        <div class="work-info">
          <button class="btn" @click="showPreviousSalesModal = true">Previous sales</button>
        </div>

        <!-- Previous sales modal (unchanged except for class names) -->
        <div v-if="showPreviousSalesModal" class="modal-overlay">
          <div class="modal">
            <h3 class="modal-title">Sales for {{ todayDate }}</h3>
            <p class="total-sales"><strong>Total Sales Amount:</strong> {{ totalSalesAmount }} uah</p>
            <div class="receipt-list scrollable receipt-lista">
              <div v-for="receipt in salesReceipts" :key="receipt.id" class="receipt-item receipt-itema">
                <p class="receipt-id"><strong>Receipt ID:</strong> {{ receipt.id }}</p>
                <ul class="receipt-items">
                  <li v-for="item in receipt.items" :key="item.product_id" class="receipt-item-detail">
                    <span class="item-name">{{ item.name }}</span> -
                    <span class="item-quantity">Quantity: {{ item.quantity }}</span>,
                    <span class="item-price">Price: {{ item.price }}</span>,
                    <span class="item-total">Total: {{ item.total }}</span>
                  </li>
                </ul>
                <p class="receipt-total"><strong>Receipt Total:</strong> {{ receipt.total }}</p>
              </div>
            </div>
            <button class="btn close-btn" @click="closePreviousSalesModal">Close</button>
          </div>
        </div>

        <!-- Active checkbox area -->
        <div class="products-wrapper">
          <div class="products-inner">
            <h2 class="products-h">Products in cheque</h2>
            <div class="btnCreate">
              <button class="btn" @click="showSelectModal = true">Add product to cheque</button>
            </div>
            <div class="products">
              <div class="product" v-for="product in filteredProducts" :key="product.supply_id">
                <img :src="product.image_url" alt="Product Image" class="product-image" />
                <h4 class="product-name">Name: {{ product.name }}</h4>
                <p class="product-description">Sale price: {{ product.sale_price }}</p>
                <p class="product-price">Purchase price: {{ product.purchase_price }}</p>
                <p class="product-quantity">Size weight: {{ product.size_weight }}</p>
                <p class="product-category">Producer: {{ product.producer }}</p>
                <p class="product-category">In stock: {{ product.quantity }}</p>
                <input
                  type="number"
                  v-model.number="product.count"
                  :min="1"
                  :max="product.quantity"
                  @input="validateCount(product)"
                />
                <button class="btn remove-btn" @click="removeFromCheckbox(product.supply_id)">Remove</button>
              </div>
            </div>
          </div>

          <!-- Pagination for items already in cheque -->
          <div class="pagination">
            <button
              :disabled="currentPageAdd === 1"
              @click="currentPageAdd--"
              class="pagination-button btn"
            >
              Previous
            </button>
            <span>Page {{ currentPageAdd }} of {{ totalPagesAdd }}</span>
            <button
              :disabled="currentPageAdd === totalPagesAdd || totalPagesAdd === 0"
              @click="currentPageAdd++"
              class="pagination-button btn"
            >
              Next
            </button>
          </div>
        </div>

        <!-- Confirm sale -->
        <div class="btnCreate">
          <button class="btn" style="margin: 20px 0px;" @click="showConfirmSaleModal = true">Confirm sale</button>
        </div>

        <div v-if="showConfirmSaleModal" class="modal-overlay">
          <div class="modal">
            <h3>Confirm Sale</h3>
            <div class="receipt">
              <div
                v-for="item in checkbox"
                :key="item.supply_id"
                class="receipt-item width receipt-element receipt-item1"
              >
                <p>{{ item.name }}</p>
                <p>{{ item.count }} x {{ item.sale_price }}</p>
                <p>total: {{ item.count * item.sale_price }}</p>
              </div>
              <hr />
              <p><strong>Total Amount: {{ totalAmount }}</strong></p>
            </div>
            <div class="payment-method">
              <label>
                <input type="radio" value="cash" v-model="paymentType" /> Cash
              </label>
              <label>
                <input type="radio" value="card" v-model="paymentType" /> Card
              </label>
            </div>
            <div>
              <button class="btn" @click="confirmSale">Confirm</button>
              <button class="btn" @click="closeConfirmSaleModal">Cancel</button>
            </div>
          </div>
        </div>

        <!-- Select product modal -->
        <div v-if="showSelectModal" class="modal-overlay modal-overlay1">
          <div class="modal1 modalselect modal3">
            <h3>Select Product to add to cheque</h3>
            <div class="search-pannel">
              <input
                type="text"
                v-model="searchQueryAdd"
                placeholder="Search by name..."
                class="search-input"
              />
              <div class="category-block">
                <div class="categories-history">
                  <div
                    class="category-history"
                    @click="selectCategory(cat.id)"
                    v-for="cat in categoriesHistory"
                    :key="cat.id"
                  >
                    {{ cat.name }} /
                  </div>
                </div>
                <h3>Categories</h3>
                <div class="categories">
                  <div class="category-btn-block" v-for="cat in categories" :key="cat.id">
                    <button class="category" @click="selectCategory(cat.id)">{{ cat.name }}</button>
                  </div>
                </div>
              </div>
            </div>
            <div class="products">
              <div class="product" v-for="product in paginatedProducts" :key="product.supply_id">
                <img :src="product.image_url" alt="Product Image" class="product-image" />
                <h4 class="product-name">Product name: {{ product.name }}</h4>
                <p class="product-description">Product sale price: {{ product.sale_price }}</p>
                <p class="product-price">Product purchase price: {{ product.purchase_price }}</p>
                <p class="product-quantity">Product size weight: {{ product.size_weight }}</p>
                <p class="product-avail">Available: {{ product.quantity }}</p>
                <button
                  :disabled="product.quantity === 0"
                  @click="openQuantityModal(product)"
                  class="pagination-button btn"
                >
                  Add to cheque
                </button>
              </div>
            </div>
            <div class="pagination">
              <button
                :disabled="currentPage === 1"
                @click="currentPage--"
                class="pagination-button btn"
              >
                Previous
              </button>
              <span>Page {{ currentPage }} of {{ totalPages }}</span>
              <button
                :disabled="currentPage === totalPages || totalPages === 0"
                @click="currentPage++"
                class="pagination-button btn"
              >
                Next
              </button>
            </div>
            <button class="btn" @click="closeModal">Close</button>
          </div>
        </div>

        <!-- Quantity input modal -->
        <div v-if="showQuantityModal" class="modal-overlay">
          <div class="modal">
            <h3>Enter Quantity (max {{ selectedProduct ? selectedProduct.quantity : 1 }})</h3>
            <input
              type="number"
              v-model.number="quantityInput"
              :min="1"
              :max="selectedProduct ? selectedProduct.quantity : 1"
            />
            <div>
              <button class="btn" @click="confirmAddProduct">Confirm</button>
              <button class="btn" @click="closeQuantityModal">Cancel</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'WorkC',
  created() {
    const shop_id = this.$route.params.id;
    this.$store.dispatch('fetchShopById', shop_id);
    this.$store.dispatch('fetchAllProducts', { shop_id, category_id: 1 });
    this.$store.dispatch('getProducts', { shop_id, category_id: 1 });
    this.$store.dispatch('fetchCategoriesByParent', 1);
    this.$store.dispatch('fetchReceipts', { shop_id });
  },
  data() {
    return {
      showSelectModal: false,
      showQuantityModal: false,
      showConfirmSaleModal: false,
      showPreviousSalesModal: false,
      quantityInput: 1,
      selectedProduct: null,
      searchQueryAdd: '',
      searchQuery: '',
      selectedCategory: '',
      currentPage: 1,
      currentPageAdd: 1,
      itemsPerPage: 3,
      categoriesHistory: [{ id: 1, name: 'All Products' }],
      checkbox: [],
      paymentType: 'cash',
    };
  },
  methods: {
    /* ---------- UI helpers ---------- */
    headCategory() {
      const shop_id = this.$route.params.id;
      this.categoriesHistory = [{ id: 1, name: 'All Products' }];
      this.$store.dispatch('fetchAllProducts', { shop_id, category_id: 1 });
      this.$store.dispatch('getProducts', { shop_id, category_id: 1 });
      this.$store.dispatch('fetchCategoriesByParent', 1);
    },
    selectCategory(categoryId) {
      const index = this.categoriesHistory.findIndex((cat) => cat.id === categoryId);
      if (index !== -1) {
        this.categoriesHistory = this.categoriesHistory.slice(0, index + 1);
      } else {
        const category = this.categories.find((cat) => cat.id === categoryId);
        if (category) {
          this.categoriesHistory.push(category);
        }
      }
      const shop_id = this.$route.params.id;
      this.$store.dispatch('fetchCategoriesByParent', categoryId);
      this.$store.dispatch('getProducts', { shop_id, category_id: categoryId });
      this.$store.dispatch('fetchAllProducts', { shop_id, category_id: categoryId });
    },
    goBack() {
      this.$router.go(-1);
    },
    /* ---------- Quantity & checkbox ---------- */
    openQuantityModal(product) {
      this.selectedProduct = product;
      this.quantityInput = 1;
      this.showQuantityModal = true;
    },
    closeQuantityModal() {
      this.showQuantityModal = false;
      this.selectedProduct = null;
    },
    confirmAddProduct() {
      if (!this.selectedProduct) return;
      const qty = this.quantityInput;
      if (qty < 1 || qty > this.selectedProduct.quantity) {
        alert(`Please enter a quantity between 1 and ${this.selectedProduct.quantity}`);
        return;
      }
      this.addProductToShop(this.selectedProduct, qty);
      this.closeQuantityModal();
    },
    addProductToShop(product, count) {
      if (product.quantity === 0) return;
      const newItem = { ...product, count };
      this.checkbox.push(newItem);
      this.showSelectModal = false;
    },
    validateCount(product) {
      if (product.count < 1) product.count = 1;
      if (product.count > product.quantity) product.count = product.quantity;
    },
    removeFromCheckbox(supply_id) {
      this.checkbox = this.checkbox.filter((p) => p.supply_id !== supply_id);
    },
    /* ---------- Sale processing ---------- */
    confirmSale() {
      if (this.checkbox.some((item) => item.count > item.quantity)) {
        alert('One or more items exceed available stock. Please adjust quantities.');
        return;
      }
      const shop_id = this.$route.params.id;
      const saleDetails = {
        products: this.checkbox,
        paymentType: this.paymentType,
        shop_id,
      };
      this.$store.dispatch('confirmSale', saleDetails).then(() => {
        this.checkbox = [];
        this.closeConfirmSaleModal();
        /* Optionally refresh stock levels */
        this.headCategory();
      });
    },
    closeConfirmSaleModal() {
      this.showConfirmSaleModal = false;
    },
    closeModal() {
      this.showSelectModal = false;
      this.headCategory();
    },
    closePreviousSalesModal() {
      this.showPreviousSalesModal = false;
    },
  },
  computed: {
    categories() {
      return this.$store.getters.getCategories;
    },
    salesReceipts() {
      return this.$store.getters.getReceipts || [];
    },
    shop() {
      return this.$store.getters.getShop || {};
    },
    products() {
      return this.$store.getters.getProducts || [];
    },
    /* --- products list in modal (excluding already in cheque) --- */
    paginatedProducts() {
      const filtered = this.products.filter((product) => {
        const inCheque = this.checkbox.some((p) => p.supply_id === product.supply_id);
        const matches = this.searchQueryAdd
          ? product.name.toLowerCase().includes(this.searchQueryAdd.toLowerCase())
          : true;
        return !inCheque && matches;
      });
      const start = (this.currentPage - 1) * this.itemsPerPage;
      return filtered.slice(start, start + this.itemsPerPage);
    },
    totalPages() {
      const filtered = this.products.filter((product) => {
        return this.searchQueryAdd
          ? product.name.toLowerCase().includes(this.searchQueryAdd.toLowerCase())
          : true;
      });
      return Math.ceil(filtered.length / this.itemsPerPage);
    },
    /* --- products inside cheque panel --- */
    filteredProducts() {
      const start = (this.currentPageAdd - 1) * this.itemsPerPage;
      return this.checkbox.slice(start, start + this.itemsPerPage);
    },
    totalPagesAdd() {
      return Math.ceil(this.checkbox.length / this.itemsPerPage) || 1;
    },
    totalAmount() {
      return this.checkbox.reduce((sum, item) => sum + item.count * item.sale_price, 0);
    },
    todayDate() {
      return new Date().toLocaleDateString();
    },
    totalSalesAmount() {
      return this.salesReceipts.reduce((sum, rcpt) => {
        return sum + rcpt.items.reduce((sub, item) => sub + item.total, 0);
      }, 0);
    },
  },
  watch: {
    searchQueryAdd() {
      this.currentPage = 1;
    },
    searchQuery() {
      this.currentPageAdd = 1;
    },
  },
};
</script>
<style>
.btnCreate{
  display: flex;
  align-items: center;
  justify-content: center;
}
.shop-name, .shop-address, .work-schedule{
    text-align: center;
    margin-top: 10px;
  }
  .products-h{
    text-align: center;
  }
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  justify-content: center;
  align-items: center;
}
.modal {
  background: white;
  padding: 30px;
  border-radius: 10px;
  width: 400px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
}
.modal1{
  background: white;
  padding: 20px;
  border-radius: 5px;
  width: 60%;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}
.modal3{
  height: 750px !important;
}
.modal h3 {
  font-size: 1.8em;
  margin-bottom: 20px;
  color: #333;
}
.modal p {
  margin: 10px 0;
  font-size: 16px;
  text-align: center;
}
.modal form label {
  display: block;
  margin-bottom: 10px;
}
.modal form input {
  width: 100%;
  padding: 5px;
  margin-top: 5px;
}
.modal form button {
  margin-right: 10px;
}
.modal input {
  margin: 10px 0;
  width: 80%;
}
.search-pannel {
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 20px 0;
}
.search-input {
  padding: 5px;
  border: 1px solid #ccc;
  border-radius: 15px;
  padding: 10px 20px;
  width: 40%;
}
.category-dropdown {
  padding: 5px;
  margin-right: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.search-button {
  padding: 5px 10px;
  background-color: #000000;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.search-button:hover {
  background-color: #000000;
}
.pagination {
  display: flex;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
}
.pagination-button {
  padding: 5px 10px;
  margin: 0 5px;
  background-color: #000000;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
.pagination-button:disabled {
  background-color: #ccc;
  cursor: not-allowed;
}
.pagination-button:hover:not(:disabled) {
  background-color: #c7a229;
}
.products{
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: 20px;
  gap: 20px;
}
.product{
  border: 1px solid #ccc;
  padding: 10px;
  border-radius: 5px;
  width: 30%;
  text-align: center;
  background-color: #f9f9f9;
}

.category-block {
  margin: 20px 0;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 8px;
  background-color: #f9f9f9;
}

.categories-history {
  display: flex;
  flex-wrap: wrap;
  margin-bottom: 10px;
}

.category-history {
  margin-right: 5px;
  cursor: pointer;
  font-weight: bold;
}

.category-history:hover {
  text-decoration: underline;
}

.categories {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

.category-btn-block {
  display: inline-block;
}

.category {
  padding: 8px 12px;
  background-color: #000000;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.category:hover {
  background-color: #be9d2f;
}

input {
  padding: 10px;
  margin: 10px 0;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 14px;
  box-sizing: border-box;
}

input:focus {
  border-color: #c7a229;
  outline: none;
  box-shadow: 0 0 5px #c7a229;;
}

.delete-button {
  padding: 5px 10px;
  background-color: #ff4d4d;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.delete-button:hover {
  background-color: #e60000;
}

.receipt {
  width: 100%;
  margin-bottom: 20px;
  text-align: left;
}
.width{
  width: 100% !important;
}
.receipt-item {
  display: flex;
  justify-content: space-between;
  margin-bottom: 10px;
  font-size: 1em;
  color: #555;
}
.receipt-item p {
  margin: 0;
}
hr {
  border: none;
  border-top: 1px solid #ddd;
  margin: 15px 0;
}
.payment-method {
  display: flex;
  justify-content: space-around;
  width: 100%;
  margin-bottom: 20px;
}
.payment-method label {
  font-size: 1em;
  color: #333;
  cursor: pointer;
}
.payment-method input {
  margin-right: 5px;
}
.modal button {
  width: 120px;
  padding: 10px;
  margin: 5px;
  background-color: #000000;
  color: white;
  border: none;
  border-radius: 5px;
  font-size: 1em;
  cursor: pointer;
  transition: background-color 0.3s ease;
}
.modal button:hover {
  background-color: #c7a229;
}
.modal button:focus {
  outline: none;
  box-shadow: 0 0 5px #c7a229;
}
.scrollable {
  max-height: 300px;
  overflow-y: auto;
  padding-right: 10px;
}
.scrollable::-webkit-scrollbar {
  width: 8px;
}
.scrollable::-webkit-scrollbar-thumb {
  background-color: #c7a229;
  border-radius: 4px;
}
.scrollable::-webkit-scrollbar-thumb:hover {
  background-color: #a67c1a;
}
.modal-title {
  font-size: 1.5em;
  margin-bottom: 20px;
  text-align: center;
  color: #333;
}

.receipt-list {
  max-height: 300px;
  overflow-y: auto;
  padding: 10px;
  background-color: #f9f9f9;
  border: 1px solid #ddd;
  border-radius: 8px;
}

.receipt-item {
  margin-bottom: 20px;
  padding: 10px;
  background-color: #fff;
}

.receipt-id {
  font-weight: bold;
  margin-bottom: 10px;
}

.receipt-items {
  list-style-type: none;
  padding: 0;
  margin: 0;
}

.receipt-item-detail {
  margin-bottom: 5px;
  font-size: 0.9em;
  color: #555;
}

.item-name {
  font-weight: bold;
}

.item-quantity, .item-price, .item-total {
  margin-left: 5px;
}

.receipt-total {
  font-weight: bold;
  margin-top: 10px;
  text-align: right;
}

.receipt-divider {
  border: none;
  border-top: 1px solid #ddd;
  margin: 10px 0;
}

.close-btn {
  display: block;
  margin: 20px auto 0;
  padding: 10px 20px;
  background-color: #c7a229;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 1em;
}

.close-btn:hover {
  background-color: #a67c1a;
}
.total-sales {
  font-size: 1.2em;
  margin-bottom: 15px;
  text-align: center;
  color: #444;
}
.back-btn {
  margin-top: 10px;
}

.back-btn:hover {
  background-color: #a67c1a;
}
.receipt-element{
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.receipt-item1{
  width: 100% !important;
}
.remove-btn {
  margin-top: 10px;
  padding: 5px 10px;
  background-color: #ff4d4d;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s ease;
}

.remove-btn:hover {
  background-color: #e60000;
}
</style>